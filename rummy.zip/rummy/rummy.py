import pygame
import random
import time
import copy
from pygame.locals import *


pygame.init()
c=0
b=0
font = pygame.font.Font('freesansbold.ttf', 32)
text = font.render('END', True, (0,0,0), (255,255,255))
textRect = text.get_rect()
textRect.center = (925,325)
font1 = pygame.font.Font('freesansbold.ttf', 32)

textRect1 = text.get_rect()
textRect1.center = (50,50)


display_width = 1400
display_height = 900
j=[]
seq=0
sui=0
sequence=[]
suits=[]
seqco=[]
suico=[]
playerch=0
turn=1
k=0
p1p=0
p2p=0


gameDisplay = pygame.display.set_mode((display_width,display_height))
pygame.display.set_caption('RUMMY')
x=0
y=0
gameDisplay.fill([50,92,61])
cards=[]
for suit in("H","C","S","D"):
    for val in("A",2,3,4,5,6,7,8,9,10,"J","Q","K"):
        cards.append(str(val)+suit)          
p1=[]
p2=[]
p2su=[]
p2sun=0
cards.append("jo")
for i in range(13):
    a=random.choice(cards)
    p1.append(a)
    cards.remove(a)
for i in range(13):
    a=random.choice(cards)
    p2.append(a)
    cards.remove(a)
run=True
p1.sort()
ch=1
cardimg=[]
cardtop=[]
q=random.choice(cards)
a=pygame.image.load(q+".png").convert()
b=pygame.transform.scale(a,(70,70))
gameDisplay.blit(b, (100,300))
cards.remove(q)
cardtop.append((q,b))
a=pygame.image.load("red_back.png").convert()
b=pygame.transform.scale(a,(70,70))
gameDisplay.blit(b, (250,300))
a=pygame.image.load("green_back1.png").convert()
b=pygame.transform.scale(a,(100,200))
gameDisplay.blit(b, (550,300))
a=pygame.image.load("gray_back1.png").convert()
b=pygame.transform.scale(a,(100,200))
gameDisplay.blit(b, (650,300))
while(run):
    textsu = font.render('suits:'+str(sui), True, (0,0,0), (255,255,255))
    textRectsu = textsu.get_rect()
    textRectsu.center = (600,100)
    gameDisplay.blit(textsu, textRectsu)
    textseq = font.render('sequences:'+str(seq), True, (0,0,0), (255,255,255))
    textRectseq = textseq.get_rect()
    textRectseq.center = (800,100)
    gameDisplay.blit(textseq, textRectseq)
    texttu = font.render('Turn No:'+str(turn), True, (0,0,0), (255,255,255))
    textRecttu = texttu.get_rect()
    textRecttu.center = (700,200)
    gameDisplay.blit(texttu, textRecttu)
    textde = font.render('Declare', True, (0,0,0), (255,255,255))
    textRectde = textde.get_rect()
    textRectde.center = (900,200)
    gameDisplay.blit(textde, textRectde)
    if(ch==1):
        for i in p1:
            a=pygame.image.load(i+".png").convert()
            b=pygame.transform.scale(a,(70,70))
            gameDisplay.blit(b, (x,600))
            cardimg.append((x,i,b))
            x+=80
            pygame.display.update()
        
        gameDisplay.blit(text, textRect)
        ch=0
        
        


    pygame.display.update()
    if(playerch==0):
        text1 = font.render('Your  ', True, (0,0,0), (255,255,255))
        gameDisplay.blit(text1, textRect1)
    #gameDisplay.blit(text3, textRect3)
    for event in pygame.event.get():
            if(event.type==pygame.QUIT):
                run=False
            if event.type == pygame.MOUSEBUTTONDOWN and c!=5:
                # Set the x, y postions of the mouse click
                x, y = event.pos
                for i in cardimg:
                    if(int(x)>int(i[0]) and int(x)<int(i[0])+80 and int(y)<700 and int(y)>600):
                        """time.sleep(1000)
                        for event2 in pygame.event.get():
                            if event2.type==pygame.MOUSEBUTTONDOWN:
                                x1,y1=event2.pos
                                if(x1>100 and x1<150 and y1>300 and y1<350):
                                    gameDisplay.blit(cardtop[1],(x,y))
                                    gameDisplay.blit(i[2],(100,300))
                                    cardtop=[]
                                    cardtop.append(i[1],i[2])"""
                        
                        c=1
                        x1=i[0]
                        y1=600
                        j=(copy.deepcopy(i[0]),copy.deepcopy(i[1]),i[2])
                        
                        break
                        
                if(x>100 and x<150 and y>300 and y<350):
                    if(c==1):
                        gameDisplay.blit(j[2],(100,300))
                        gameDisplay.blit(cardtop[0][1],(x1,y1))
                        temp=cardtop[0][0]
                        cardimg.append((x1,cardtop[0][0],cardtop[0][1]))
                        cardtop=[(j[1],j[2])]
                        cardimg.remove(j)
                        p1.remove(j[1])
                        p1.append(temp)

                        pygame.display.update()
                        c=0
                        
                if(x>250 and x<300 and y>300 and y<350):
                    if(c==0 or c==1):
                        #gameDisplay.blit(j[2],(100,300))
                        l=random.choice(cards)
                        a=pygame.image.load(l+".png")
                        b=pygame.transform.scale(a,(70,70))
                        gameDisplay.blit(b,(400,300))
                        c=2
                        
                if(x>400 and x<450 and y>300 and y<350):
                    if(c==1):
                      gameDisplay.blit(j[2],(100,300))
                      gameDisplay.blit(b,(x1,y1))
                      cover=pygame.image.load("purple_back.png")
                      cover=pygame.transform.scale(cover,(70,70))
                      gameDisplay.blit(cover,(400,300))
                      cards.remove(l)
                      cardtop=[(j[1],j[2])]
                      cardimg.append((x1,l,b))
                      cardimg.remove(j)
                      #print(j[1])
                      p1.remove(j[1])
                      p1.append(l) 
                      cardimg.append((x1,j[1],j[2]))
                      #print(l)
                      #print(p1)
                      c=0
                if(x>100 and x<150 and y>300 and y<350):
                    if(c==2):
                        #gameDisplay.blit(j[2],(100,300))
                        #gameDisplay.blit(b,(x1,y1))
                        cover=pygame.image.load("purple_back.png")
                        cover=pygame.transform.scale(cover,(70,70))
                        gameDisplay.blit(cover,(400,300))
                        gameDisplay.blit(b,(100,300))
                        cards.remove(l)
                if(x>550 and x<650 and y>300 and y<500):
                    if(c==1):
                        
                        if(j[1][0].isdigit()):

                            sequence.append(int(j[1][0]))
                            seqco.append((x1,j[2],j[1]))
                        else:
                            if(j[1][0]=="K"):
                                sequence.append(13)
                            elif(j[1][0]=="Q"):
                                sequence.append(12)
                            elif(j[1][0]=="J"):
                                sequence.append(11)
                            elif(j[1][0]=="j"):
                                sequence.append(100)
                            else:
                                sequence.append(1)
                        #print(sequence[-1])
                        if((len(sequence)>1 and abs(sequence[-1]-sequence[-2])==1) or len(sequence)==1 or sequence[-1]==100):

                            covercar=pygame.image.load("yellow_back.png")
                            covercar=pygame.transform.scale(covercar,(70,70))
                            gameDisplay.blit(covercar,(x1,600))
                            p1.remove(j[1])
                        else:
                            sequence.pop() 
                            seqco.pop()
                if(x>650 and x<750 and y>300 and y<500):
                    if(c==1):
                        
                        suits.append(j[1])
                        #print(suits[0][0],j[1][0])
                        suico.append((x1,j[2],j[1]))
                        if((len(suits)>0 and j[1][0]==suits[0][0]) or len(suits)==0 or j[1][0]=="j"):
                            covercar=pygame.image.load("yellow_back.png")
                            covercar=pygame.transform.scale(covercar,(70,70))
                            gameDisplay.blit(covercar,(x1,600))
                            p1.remove(j[1])
                        else:
                            suits.pop()
                            suico.pop()

                            
                if(x>900 and x<950 and y>300 and y<350):
                    playerch=1
                    text1 = font.render('Comp', True, (0,0,0), (255,255,255))
                    gameDisplay.blit(text1,textRect1)
                    if(len(sequence)==1):
                        gameDisplay.blit(seqco[0][1],(seqco[0][0],600))
                        p1.append(seqco[0][2])
                        
                    if(len(sequence)==2):
                        gameDisplay.blit(seqco[0][1],(seqco[0][0],600))
                        gameDisplay.blit(seqco[1][1],(seqco[1][0],600))
                        p1.append(seqco[0][2])
                        p1.append(seqco[1][2])
                        
                    if(len(suits)==1):
                        gameDisplay.blit(suico[0][1],(suico[0][0],600))
                        p1.append(suico[0][2])
                        
                    if(len(suits)==2):
                        gameDisplay.blit(suico[0][1],(suico[0][0],600))
                        gameDisplay.blit(suico[1][1],(suico[1][0],600))
                        p1.append(suico[0][2])
                        p1.append(suico[1][2])
                    if(len(suits)>=3):
                        sui+=1
                    if(len(sequence)>=3):
                        seq+=1
                    
                    
                    sequence=[]
                    suits=[]
                    turn+=1
                    #print(p1)
                    #print(sui)
                if(x>810 and y>170 and y<230 and x<980):
                    c=5
                    p2.sort()
                    x=0
                    p2new=copy.deepcopy(p2)
                    for i in range(len(p2)-2):
                        if(p2[i][0]==p2[i+1][0] and p2[i][0]==p2[i+2][0]):
                            p2sun+=1
                            p2new.remove(p2[i])
                            p2new.remove(p2[i+1])
                            p2new.remove(p2[i+2])
                    p2=p2new
                    for i in p1:
                        if(i[0].isdigit() and i[0]!="1"):
                            p1p+=int(i[0])
                        elif(i[0]=="1"):
                            p1p+=10
                        elif(i[0]=="A"):
                            p1p+=1
                        elif(i[0]=="K" or i[0]=="J" or i[0]=="Q"):
                            p1p+=10
                    for i in p2:
                        if(i[0].isdigit() and i[0]!="1"):
                            p2p+=int(i[0])
                        elif(i[0]=="1"):
                            p2p+=10
                        elif(i[0]=="A"):
                            p2p+=1
                        elif(i[0]=="K" or i[0]=="J" or i[0]=="Q"):
                            p2p+=10
                        
                    for i in p2:
                        a=pygame.image.load(i+".png").convert()
                        b=pygame.transform.scale(a,(70,70))
                        gameDisplay.blit(b, (x,700))
                        cardimg.append((x,i,b))
                        x+=80
                        pygame.display.update()
                    if(len(p1)==0 and sui+seq>=2 and p2p>p1p):
                        textwi = font.render('You Win', True, (0,0,0), (255,255,255))
                        textRectwi = textwi.get_rect()
                        textRectwi.center = (1000,200)
                        gameDisplay.blit(textwi, textRectwi)
                    if(len(p1)==0 and sui+seq>=2 and p1p==p2p):
                        textwi = font.render('Draw', True, (0,0,0), (255,255,255))
                        textRectwi = textwi.get_rect()
                        textRectwi.center = (1000,200)
                        gameDisplay.blit(textwi, textRectwi)
                    else:
                        textwi = font.render('You Lose', True, (0,0,0), (255,255,255))
                        textRectwi = textwi.get_rect()
                        textRectwi.center = (1200,200)
                        gameDisplay.blit(textwi, textRectwi)   
                     
                        
                    textco = font.render('Comp Runs:'+str(p2sun), True, (0,0,0), (255,255,255))
                    textRectco = textco.get_rect()
                    textRectco.center = (1200,250)
                    gameDisplay.blit(textco, textRectco)
                    textco = font.render('Player Points:'+str(p1p), True, (0,0,0), (255,255,255))
                    textRectco = textco.get_rect()
                    textRectco.center = (1200,350)
                    gameDisplay.blit(textco, textRectco)
                    textco = font.render('Comp Points:'+str(p2p), True, (0,0,0), (255,255,255))
                    textRectco = textco.get_rect()
                    textRectco.center = (1200,450)
                    gameDisplay.blit(textco, textRectco)
                    
                    

              

              
                    
                pygame.display.update() 
                if(playerch==1):
                   
                    pygame.time.wait(1000)

                    choice=random.randint(0,1)
                    #print(choice)
                    for t in p2:
                        if(t[0]==cardtop[0][0][0]):
                            p2c=random.choice(p2)
                            p2.remove(p2c)
                            a=pygame.image.load(p2c+".png")
                            b=pygame.transform.scale(a,(70,70))
                            gameDisplay.blit(b,(100,300))
                            p2.append(cardtop[0][0])
                            cardtop=[(p2c,b)]
                            k=1
                            playerch=0
                            cards.append(p2c)
                            #l=random.choice(cards)
                            a=pygame.image.load(p2c+".png")
                            b=pygame.transform.scale(a,(70,70))
                            cardtop=[(p2c,b)]
                            #print(2)
                            break
                        

                    if(choice==1 and k!=1):
                        l=random.choice(cards)
                        a=pygame.image.load(l+".png")
                        b=pygame.transform.scale(a,(70,70))
                        gameDisplay.blit(b,(400,300))
                        pygame.time.wait(1000)
                        p2c=random.choice(p2)
                        p2.remove(p2c)
                        p2.append(l)
                        cover=pygame.image.load("purple_back.png")
                        cover=pygame.transform.scale(cover,(70,70))
                        gameDisplay.blit(cover,(400,300))
                        gameDisplay.blit(b,(100,300))
                        cards.remove(l)
                        cardtop=[(l,b)]
                        #p2.append(l)
                        playerch=0
                        k=0
                    if(choice==0 and k!=1):
                        pygame.time.wait(1000)
                        p2c=random.choice(p2)
                        p2.remove(p2c)
                        a=pygame.image.load(p2c+".png")
                        b=pygame.transform.scale(a,(70,70))
                        gameDisplay.blit(b,(100,300))
                        p2.append(cardtop[0][0])
                        cardtop=[(p2c,b)]
                        playerch=0
                        k=0
                    c=0
                        

                    pygame.display.update()   
                
                    
                   
                    
              
                    
                    

 
    



                
                    

