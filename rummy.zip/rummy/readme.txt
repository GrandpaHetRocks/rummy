13 cards dealt to each player
3 or more cards of same value or in a sequence can be undealt
can declare in the middle of the game
no of runs>2 to win
Winning depends on number of points.lesser points the better.